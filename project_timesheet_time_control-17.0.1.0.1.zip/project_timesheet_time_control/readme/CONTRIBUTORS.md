- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Antonio Espinosa
  > - Carlos Dauden
  > - Sergio Teruel
  > - Luis M. ontalba
  > - Ernesto Tejeda
  > - Jairo Llopis
  > - Carlos Roca

- [Sygel](https://www.sygel.es):

  > - Valentín Vinagre
  > - Roger Sans

