## Module <om_account_followup>

#### 19.05.2024
#### Version 17.0.1.0.1
##### ADD
- sanitize sql query

#### 22.11.2023
#### Version 17.0.1.0.0
##### ADD
- initial release



