## Module <legal_case_management>

#### 30.11.2023
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Legal Case Management
