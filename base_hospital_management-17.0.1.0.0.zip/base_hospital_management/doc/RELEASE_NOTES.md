## Module <base_hospital_management>

#### 03.06.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Hospital Management Odoo 17
