## Module <oh_hr_lawsuit_management>

#### 28.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Open HRMS Legal Actions

#### 26.06.2024
#### Version 17.0.1.0.1
##### UPDT
- Updated the Menu item positions 
