Date: 01/04/2024 | Version: 17.0.0.1
	Fixed: Fixed Bad Query error.
	Fixed: Fixed create method error.
	Fixed: Fixed warnings.


17.0.0.2 ==> Fixed mention issue of when medicament create from prescription order line at that time trace back occur.
	
	